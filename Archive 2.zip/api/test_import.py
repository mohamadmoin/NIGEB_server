import csv
from datetime import datetime
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'trauma.settings')
django.setup()

from api.models import TestInfos  # Replace 'myapp' with your actual app name

def import_books(file_path):
    with open(file_path, 'r') as file:
        
        reader = csv.DictReader(file)
        for row in reader:
            TestInfos.objects.create(
            # id_id = row['\ufeffid'],
            
            # testCode = row['testCode'],
            testName = row['\ufefftest'],
            group = row['group'],
            unit = row['unit'],
            # description = row['description'],
            normal_range = row['normalrange'],
            # k_total = row['k_total'],
            # k_fani = row['k_fani'],
            # k_herfe = row['k_herfe'],
            # testCost1 = row['testCost1'],
            # testCost2 = row['testCost2'],
            # testCost3 = row['testCost3'],
            # testCost4 = row['testCost4'],
        )

              
            
if __name__ == '__main__':
    csv_file_path = 'tests.csv'  # Replace with your actual file path
    import_books(csv_file_path)
